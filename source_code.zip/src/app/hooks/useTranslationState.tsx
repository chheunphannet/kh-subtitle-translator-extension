"use client";

import { useState } from "react";
import { App } from "antd";
import { useLocalStorage } from "@/app/hooks/useLocalStorage";
import useFileUpload from "@/app/hooks/useFileUpload";
import { useLlmPresets } from "@/app/hooks/useLlmPresets";
import { usePromptPresets } from "@/app/hooks/usePromptPresets";
import { useTranslationProgress } from "@/app/hooks/useTranslationProgress";
import {
  generateCacheSuffix,
  splitTextIntoChunks,
  testTranslation,
  useTranslation,
  defaultConfigs,
  deriveThinkingParams,
  getDefaultConfig,
  migrateConfig,
  resetConfigWithCredentials,
  LLM_MODELS,
  DEFAULT_SYSTEM_PROMPT,
  DEFAULT_USER_PROMPT,
  translategemmaHealthCheck,
  type TranslateTextParams,
  type TranslationConfig,
} from "@/app/lib/translation";
import {
  getRetryConfig,
  delay,
  extractTranslatedLinesWithNumbers,
  buildContextPrompt,
  exportTranslationSettings,
  createSettingsFileInput,
  validateTranslationInputs,
  DEFAULT_RETRY_COUNT,
  DEFAULT_RETRY_TIMEOUT,
  isAuthError,
  type TranslationSettings,
  type UserRetryConfig,
} from "@/app/hooks/translation";
import pLimit from "p-limit";
import pRetry from "p-retry";
import { useTranslations } from "next-intl";

const DEFAULT_API = "gtxFreeAPI";
// Caps context window padding around a batch — without this, a large
// contextWindow would request hundreds of neighbor lines per batch and blow
// past the model's context limit on long inputs.
const MAX_CONTEXT_PADDING = 50;

type TranslationConfigs = Record<string, TranslationConfig>;

type PerformTranslation = (sourceText: string, fileNameSet?: string, fileIndex?: number, totalFiles?: number, documentType?: "subtitle" | "markdown" | "generic") => Promise<void>;

type TranslationRuntimeConfig = TranslationConfig & {
  translationMethod: string;
  targetLanguage: string;
  sourceLanguage: string;
  useCache?: boolean;
  fullText?: string; // Complete text for ${fullText} variable
};

const useTranslationState = () => {
  const { message } = App.useApp();
  const tLanguages = useTranslations("languages");
  const t = useTranslations("common");
  const { translate } = useTranslation();
  const { readFile } = useFileUpload();

  // State
  const [useCache, setUseCache] = useState<boolean>(true);
  // Drawer for the full provider/model/prompt config surface. Replaces the
  // previous "Advanced" Tab; sits per-translator inside TranslationProvider.
  const [apiSettingsOpen, setApiSettingsOpen] = useState<boolean>(false);
  const [translationMethod, setTranslationMethod] = useLocalStorage<string>("translation-method", DEFAULT_API);
  // localStorage 残留旧/已删 service key (比如重命名前的 "aliyun" 或 已 retire 的
  // method) → getDefaultConfig 返回 undefined。getSelectedConfig 内部翻译路径会
  // fallback,但 translationMethod state 本身没修,ApiStatusBlock 的 Select 会显示
  // 空白值。render-time 一次性纠偏,覆盖所有 mount 入口 (而非只 Drawer 打开时)。
  if (!getDefaultConfig(translationMethod)) {
    setTranslationMethod(DEFAULT_API);
  }
  const [translationConfigs, setTranslationConfigs] = useLocalStorage<TranslationConfigs>("translation-configs", defaultConfigs as TranslationConfigs);
  const [systemPrompt, setSystemPrompt] = useLocalStorage<string>("translation-systemPrompt", DEFAULT_SYSTEM_PROMPT);
  const [userPrompt, setUserPrompt] = useLocalStorage<string>("translation-userPrompt", DEFAULT_USER_PROMPT);
  const [sourceLanguage, setSourceLanguage] = useLocalStorage<string>("translation-sourceLanguage", "auto");
  const [targetLanguage, setTargetLanguage] = useLocalStorage<string>("translation-targetLanguage", "km");
  const [targetLanguages, setTargetLanguages] = useLocalStorage<string[]>("translation-targetLanguages", ["km"]);
  const [removeChars, setRemoveChars] = useLocalStorage<string>("translation-removeChars", "");
  const [multiLanguageMode, setMultiLanguageMode] = useLocalStorage<boolean>("translation-multiLanguageMode", false);
  const [retryCount, setRetryCount] = useLocalStorage<number>("translation-retryCount", DEFAULT_RETRY_COUNT);
  // Per-request timeout in seconds (fetch signal setTimeout).
  const [requestTimeoutSec, setRequestTimeoutSec] = useLocalStorage<number>("translation-requestTimeoutSec", DEFAULT_RETRY_TIMEOUT);
  const [translatedText, setTranslatedText] = useState<string>("");
  // Line-level soft-failure: lines still failing after retries exhaust.
  // UI shows Alert with retry button; cache hits skip re-translation.
  const [failedCount, setFailedCount] = useState<number>(0);
  const [failedLines, setFailedLines] = useState<string[]>([]);
  // Lang-level failures: in multi-language batch mode, codes of langs that
  // errored out entirely. Replaces noisy per-lang toasts. See md-translator #7.
  const [failedLangs, setFailedLangs] = useState<string[]>([]);

  const effectiveSystemPrompt = systemPrompt.trim() ? systemPrompt : DEFAULT_SYSTEM_PROMPT;
  const effectiveUserPrompt = userPrompt.trim() ? userPrompt : DEFAULT_USER_PROMPT;

  // Extracted concerns
  const { isTranslating, setIsTranslating, progressPercent, setProgressPercent, progressInfo, abortControllerRef, makeUpdateProgress, resetProgress } = useTranslationProgress();

  const { llmPresets, setLlmPresets, activeLlmPresetId, saveLlmPreset, loadLlmPreset, deleteLlmPreset, renameLlmPreset, updateLlmPreset } = useLlmPresets({
    translationConfigs,
    setTranslationConfigs,
  });

  const {
    promptPresets,
    setPromptPresets,
    activePromptPresetId,
    setActivePromptPresetId,
    savePromptPreset,
    loadPromptPreset,
    deletePromptPreset,
    renamePromptPreset,
    updatePromptPreset,
  } = usePromptPresets({
    effectiveSystemPrompt,
    effectiveUserPrompt,
    setSystemPrompt,
    setUserPrompt,
  });

  // Settings export/import
  const exportSettings = async () => {
    try {
      await exportTranslationSettings({
        translationConfigs,
        systemPrompt: effectiveSystemPrompt,
        userPrompt: effectiveUserPrompt,
        translationMethod,
        sourceLanguage,
        targetLanguage,
        targetLanguages,
        multiLanguageMode,
        llmPresets,
        promptPresets,
        activePromptPresetId,
        retryCount,
        requestTimeoutSec,
        removeChars,
      });
      message.success(t("exportSettingSuccess"));
    } catch (error) {
      console.error("Export settings error:", error);
      message.error(t("exportSettingError"));
    }
  };

  const importSettings = () => {
    return createSettingsFileInput((settings: TranslationSettings) => {
      if (settings.translationConfigs !== undefined) setTranslationConfigs(settings.translationConfigs as TranslationConfigs);
      if (settings.systemPrompt !== undefined) setSystemPrompt(settings.systemPrompt);
      if (settings.userPrompt !== undefined) setUserPrompt(settings.userPrompt);
      if (settings.translationMethod !== undefined) setTranslationMethod(settings.translationMethod);
      if (settings.sourceLanguage !== undefined) setSourceLanguage(settings.sourceLanguage);
      if (settings.targetLanguage !== undefined) setTargetLanguage(settings.targetLanguage);
      if (settings.targetLanguages !== undefined) setTargetLanguages(settings.targetLanguages);
      if (settings.multiLanguageMode !== undefined) setMultiLanguageMode(settings.multiLanguageMode);
      if (settings.llmPresets !== undefined) setLlmPresets(settings.llmPresets);
      if (settings.promptPresets !== undefined) setPromptPresets(settings.promptPresets);
      if (settings.activePromptPresetId !== undefined) setActivePromptPresetId(settings.activePromptPresetId);
      if (settings.retryCount !== undefined) setRetryCount(settings.retryCount);
      if (settings.requestTimeoutSec !== undefined) setRequestTimeoutSec(settings.requestTimeoutSec);
      if (settings.removeChars !== undefined) setRemoveChars(settings.removeChars);
      message.success(t("importSettingSuccess"));
    }, readFile).catch((error) => {
      console.error("Import settings error:", error);
      message.error(t("importSettingError"));
    });
  };

  // Config management
  // Value covers all TranslationConfig leaf types: primitives for scalar fields
  // (apiKey/temperature/useRelay/...) and Record<string, string> for thinkingEffort
  // (per-model effort level — entry presence = thinking on).
  const handleConfigChange = (method: string, field: string, value: string | number | boolean | Record<string, string>) => {
    setTranslationConfigs((prev) => {
      const existingConfig = prev[method];
      const defaultConfig = getDefaultConfig(method);

      const baseConfig = migrateConfig(existingConfig, defaultConfig);
      const next = { ...baseConfig, [field]: value } as TranslationConfig;

      // No need to strip thinking state on model switch — thinking is now
      // per-model (config.thinkingEffort record keyed by SKU), so each model's
      // state is independently preserved when switching back.

      return { ...prev, [method]: next };
    });
  };

  const resetTranslationConfig = (method: string) => {
    setTranslationConfigs((prevConfigs) => ({
      ...prevConfigs,
      [method]: resetConfigWithCredentials(prevConfigs[method], getDefaultConfig(method)),
    }));
  };

  // Pure function: Returns valid config without calling setState during render
  const getSelectedConfig = (): TranslationConfig => {
    // If selected translationMethod doesn't exist in defaults (e.g. stale key in localStorage like "aliyun" -> "qwenMt")
    let effectiveMethod = translationMethod;
    if (!getDefaultConfig(effectiveMethod)) {
      effectiveMethod = DEFAULT_API;
    }

    const existingConfig = translationConfigs[effectiveMethod];
    const defaultConfig = getDefaultConfig(effectiveMethod);

    // Merge defaults in without resetting user choices. migrateConfig is idempotent
    // and side-effect free — safe to call during render. localStorage gets
    // written back next time the user changes a setting.
    return migrateConfig(existingConfig, defaultConfig);
  };

  // Language management
  // 任何 source/target 变化都会让 translatedText invalidate——避免用户改了语言
  // 但屏幕上还显示旧译文,误以为切换没生效。
  const handleLanguageChange = (type: "source" | "target", value: string) => {
    const otherValue = type === "source" ? targetLanguage : sourceLanguage;
    if (value === otherValue) {
      if (type === "source") {
        const newTargetValue = value === "km" ? "en" : "km";
        setSourceLanguage(value);
        setTargetLanguage(newTargetValue);
        message.error(`${t("sameLanguageTarget")} ${newTargetValue === "km" ? tLanguages("km") : tLanguages("en")}`);
      } else {
        setTargetLanguage(value);
        setSourceLanguage("auto");
        message.error(`${t("sameLanguageSource")} ${tLanguages("auto")}`);
      }
      setTranslatedText("");
      return;
    }
    if (type === "source" && value !== sourceLanguage) {
      setSourceLanguage(value);
      setTranslatedText("");
    } else if (type === "target" && value !== targetLanguage) {
      setTargetLanguage(value);
      setTranslatedText("");
    }
  };

  // Swap source <-> target. Bypasses handleLanguageChange's same-language
  // guard because a swap never lands on a same-language state. Disabled by
  // the UI when sourceLanguage === "auto" (can't move "detect" to target) or
  // multiLanguageMode === true (no single target to swap against).
  const handleSwapLanguages = () => {
    const previousSource = sourceLanguage;
    setSourceLanguage(targetLanguage);
    setTargetLanguage(previousSource);
    setTranslatedText("");
  };

  // Validation
  //
  // 设计要点 (踩坑后留的注释,改之前先理解):
  //
  // 1. 不在此处碰 isTranslating —— 该 flag 由调用方 (runTranslation /
  //    handleMultipleTranslate) 的 try/finally 统一管。validate 内部自己开关
  //    会跟外层 set 冲突,触发 progress modal 闪烁,职责也乱。
  //
  // 2. 语言不支持时不再自动改 translationMethod —— 早期版本会偷偷 fallback
  //    到 DEFAULT_API,用户察觉不到 method 被换。现在只报错,让用户自己决定
  //    换语言还是换 method。
  //
  // 3. test ping 只对这 5 个服务执行 (deepl/deeplx/llm/gtxFreeAPI/translategemma):
  //    它们是"免费/自托管/本地"类,可用性不稳定 (GFW 墙、自架挂了、模型没启动)
  //    需要提前探测。付费 API (DeepSeek/Claude/Gemini 等) 假定 API key 给了就能
  //    用,出错让翻译请求本身去报。
  //
  // 4. test ping 失败时只有 deeplx 自动 fallback —— deeplx 是自托管代理,
  //    URL 配错 / 服务挂了的概率最高;其他 4 个失败通常是真实问题 (key 错、
  //    服务真不可用),fallback 没意义。
  const validate = async () => {
    const config = getSelectedConfig();

    // Sync validation: creds + language support. Extracted to a pure function
    // (hooks/translation/validation.ts) so it's unit-testable without React.
    const syncResult = validateTranslationInputs({
      config,
      method: translationMethod,
      sourceLanguage,
      targetLanguage,
      multiLanguageMode,
      targetLanguages,
    });
    if (!syncResult.ok) {
      if ("errorKey" in syncResult) {
        message.error(t(syncResult.errorKey));
      } else if (syncResult.errorMessage) {
        message.error({ content: syncResult.errorMessage, duration: 10 });
      }
      return false;
    }

    if (["deepl", "deeplx", "llm", "gtxFreeAPI", "translategemma"].includes(translationMethod)) {
      // translategemma uses a lightweight reachability check (GET /v1/models)
      // instead of full inference — avoids the 5-30s wait for cold-start model
      // loading on LM Studio. Catches the common "server not running" case fast.
      let testResult: boolean;
      if (translationMethod === "translategemma") {
        testResult = await translategemmaHealthCheck(String(config.url ?? ""));
      } else {
        const tempSystemPrompt = translationMethod === "llm" ? effectiveSystemPrompt : undefined;
        const tempUserPrompt = translationMethod === "llm" ? effectiveUserPrompt : undefined;
        testResult = await testTranslation(translationMethod, config, tempSystemPrompt, tempUserPrompt);
      }
      if (testResult !== true) {
        const errorMessages: Record<string, string> = {
          deeplx: t("deepLXUnavailable"),
          deepl: t("deeplUnavailable"),
          llm: t("llmUnavailable"),
          gtxFreeAPI: t("gtxFreeAPIUnavailable"),
          translategemma: t("translategemmaUnavailable"),
        };
        if (translationMethod === "deeplx") setTranslationMethod(DEFAULT_API);
        // ⚠ Footgun: setState is async; below this line `translationMethod` in this
        // scope still reads the old value (deeplx). Currently safe because we
        // immediately `return false`. If you add code that re-reads
        // `translationMethod` after this point, expect stale value.
        message.open({ type: "error", content: errorMessages[translationMethod] || t("translationError"), duration: 10 });
        return false;
      }
    }

    return true;
  };

  // Retry translation with config - throws on failure (no fallback to original text)
  // Uses shared abortControllerRef to allow cancellation across concurrent requests
  const translateSingle = async (text: string, cacheSuffix: string, config: TranslationRuntimeConfig, fullText?: string) => {
    // Check if already aborted (e.g., by auth error in another concurrent request)
    if (abortControllerRef.current?.signal.aborted) {
      throw new Error("Translation aborted");
    }

    const userRetryConfig: UserRetryConfig = { retryCount, requestTimeoutSec };
    const retryConfig = getRetryConfig(config.translationMethod, userRetryConfig);
    const timeoutMs = requestTimeoutSec * 1000;

    // Create per-request abort controller with timeout
    // Links to shared abort controller and auto-cleans up
    const createTimeoutController = () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      // If shared controller aborts, also abort this request
      const onAbort = () => controller.abort();
      abortControllerRef.current?.signal.addEventListener("abort", onAbort, { once: true });

      return {
        controller,
        cleanup: () => {
          clearTimeout(timeoutId);
          abortControllerRef.current?.signal.removeEventListener("abort", onAbort);
        },
      };
    };

    // Build translate params - pick defined optional fields from config.
    // reasoningEffort is derived per-call from the thinkingEffort record
    // (presence of entry for current model = effort, absence = thinking off).
    const optionalFields = ["useCache", "apiKey", "region", "url", "model", "apiVersion", "temperature", "maxTokens", "systemPrompt", "userPrompt", "sendSystemPrompt", "useRelay", "domains"] as const;
    const extras: Record<string, unknown> = {};
    const configRecord = config as unknown as Record<string, unknown>;
    for (const key of optionalFields) {
      if (configRecord[key] !== undefined) {
        extras[key] = configRecord[key];
      }
    }
    // Single-point gate: deriveThinkingParams checks (a) thinkingEffort entry
    // exists AND (b) model is tagged in registry. Services key off
    // params.reasoningEffort presence (Moonshot K2.6 + Gemini also re-check
    // isThinkingModel internally — they're server-default-ON and need to send
    // explicit "disabled" / "minimal" when tagged-but-effort-undefined).
    const effort = deriveThinkingParams(config.translationMethod, config);
    if (effort) extras.reasoningEffort = effort;
    if (fullText !== undefined) extras.fullText = fullText;

    const translateParams: TranslateTextParams = {
      text,
      cacheSuffix,
      translationMethod: config.translationMethod,
      targetLanguage: config.targetLanguage,
      sourceLanguage: config.sourceLanguage,
      ...extras,
    } as TranslateTextParams;

    try {
      return await pRetry(
        async () => {
          // Check abort before each attempt
          if (abortControllerRef.current?.signal.aborted) {
            throw new Error("Translation aborted");
          }

          const { controller, cleanup } = createTimeoutController();

          try {
            const result = await translate({ ...translateParams, signal: controller.signal });
            cleanup();
            return result;
          } catch (error) {
            cleanup();

            // Check if this is an auth error - abort all concurrent requests
            if (isAuthError(error)) {
              abortControllerRef.current?.abort();
            }
            throw error;
          }
        },
        {
          ...retryConfig,
          onFailedAttempt: ({ error, attemptNumber, retriesLeft }) => {
            const textPreview = text.length > 30 ? `${text.substring(0, 30)}...` : text;
            console.warn(`Translation attempt ${attemptNumber} failed for "${textPreview}": ${(error as Error).message} (${retriesLeft} retries left)`);
          },
        },
      );
    } catch (error) {
      const textPreview = text.length > 30 ? `${text.substring(0, 30)}...` : text;
      console.error(`All ${retryCount} translation attempts failed for: "${textPreview}".`, error);
      throw error; // No fallback to original text - fail explicitly
    }
  };

  // Context-aware translation with auto-adjustment of context window
  const translateWithContext = async (
    contentLines: string[],
    runtimeConfig: TranslationRuntimeConfig,
    cacheSuffix: string,
    updateProgress: (current: number, total: number) => void,
    documentType: "subtitle" | "markdown" | "generic" = "subtitle",
    fullText?: string,
  ) => {
    // Clamp to >= 1: `|| 20` only catches 0/null/undefined, not negatives.
    // A negative contextWindow (from corrupted localStorage or bad migration)
    // would make the main loop `i += -5` → infinite loop.
    const initialContextWindow = Math.max(1, Math.min(runtimeConfig.contextWindow || 20, contentLines.length));
    const translatedLines = new Array(contentLines.length);
    const MAX_CONTEXT_RETRIES = 2; // Maximum times to reduce context window

    const translateSingleBatch = async (batchStart: number, batchEnd: number, contextWindow: number): Promise<boolean> => {
      const contextPadding = Math.min(MAX_CONTEXT_PADDING, Math.max(1, Math.floor(contextWindow / 2)));
      const contextStart = Math.max(0, batchStart - contextPadding);
      const contextEnd = Math.min(contentLines.length, batchEnd + contextPadding);
      const contextLines = contentLines.slice(contextStart, contextEnd);
      const targetStartIndex = batchStart - contextStart;
      const targetEndIndex = batchEnd - contextStart;

      const contextWithMarkers = contextLines
        .map((line, index) => {
          if (index >= targetStartIndex && index < targetEndIndex) {
            return `[TRANSLATE_${index - targetStartIndex}]${line}[/TRANSLATE_${index - targetStartIndex}]`;
          }
          return `[CONTEXT]${line}[/CONTEXT]`;
        })
        .join("\n");

      try {
        const result = await translateSingle(
          contextWithMarkers,
          cacheSuffix,
          {
            ...runtimeConfig,
            userPrompt: buildContextPrompt(contextWithMarkers, effectiveUserPrompt, batchEnd - batchStart, documentType),
          },
          fullText,
        );

        const translatedBatch = extractTranslatedLinesWithNumbers(result || "", batchEnd - batchStart);
        for (let j = 0; j < translatedBatch.length; j++) {
          if (batchStart + j < contentLines.length && translatedBatch[j]) {
            translatedLines[batchStart + j] = translatedBatch[j];
          }
        }

        // Reflect partial progress as soon as the batch returns, so the bar doesn't
        // sit at 0% for the full duration of each 50-line LLM call.
        const doneSoFar = translatedLines.filter(Boolean).length;
        if (doneSoFar > 0) updateProgress(doneSoFar, contentLines.length);

        return !translatedLines.slice(batchStart, batchEnd).includes(undefined);
      } catch (error) {
        if (isAuthError(error)) throw error;
        console.warn(`Batch ${batchStart + 1}-${batchEnd} translation error:`, error);
        return false;
      }
    };

    // Iterative batch translation with context window reduction (replaces recursion)
    const translateBatch = async (batchStart: number, batchEnd: number, contextWindow: number): Promise<boolean> => {
      const success = await translateSingleBatch(batchStart, batchEnd, contextWindow);
      if (success) return true;

      // Halve context window + retry only the still-empty index clusters (not
      // the whole sub-range) — saves tokens and prevents LLM non-determinism
      // from overwriting already-successful lines with slightly different output.
      let currentWindow = contextWindow;
      for (let attempt = 0; attempt < MAX_CONTEXT_RETRIES && currentWindow > 5; attempt++) {
        currentWindow = Math.max(5, Math.floor(currentWindow / 2));

        const missing: number[] = [];
        for (let k = batchStart; k < batchEnd; k++) {
          if (!translatedLines[k]) missing.push(k);
        }
        if (missing.length === 0) return true;

        const gapClusters = clusterAscendingIndices(missing);
        console.warn(`Batch ${batchStart + 1}-${batchEnd} incomplete (${missing.length} line(s) missing in ${gapClusters.length} gap(s)); reducing window to ${currentWindow}`);

        for (const [gs, ge] of gapClusters) {
          if (abortControllerRef.current?.signal.aborted) return false;
          await translateSingleBatch(gs, ge, currentWindow);
        }

        if (!translatedLines.slice(batchStart, batchEnd).includes(undefined)) return true;
      }

      return false;
    };

    // Helper: group contiguous failed indices into [start, end) clusters
    // (capped so a total blowout doesn't retry as one mega-batch). Reused
    // below by the batch-level fallback and the post-pass auto-retry.
    const RETRY_MAX_CLUSTER_SIZE = 10;
    const RETRY_CONTEXT_WINDOW = 6; // ±3 neighbor lines wrapped as [CONTEXT]
    const clusterAscendingIndices = (sortedIndices: number[]): Array<[number, number]> => {
      if (sortedIndices.length === 0) return [];
      const out: Array<[number, number]> = [];
      let s = sortedIndices[0];
      let e = sortedIndices[0];
      for (let k = 1; k < sortedIndices.length; k++) {
        const idx = sortedIndices[k];
        if (idx === e + 1 && e - s + 1 < RETRY_MAX_CLUSTER_SIZE) {
          e = idx;
        } else {
          out.push([s, e + 1]);
          s = idx;
          e = idx;
        }
      }
      out.push([s, e + 1]);
      return out;
    };

    // Helper: retry any still-empty slots in [rangeStart, rangeEnd) by
    // clustering them and feeding each cluster through translateSingleBatch
    // with a small context window. Keeps LLM coherence on fallback and
    // shares the ±3 neighbor context across cluster members — much cheaper
    // than the old line-by-line-without-context fallback.
    const clusterRetryFailures = async (rangeStart: number, rangeEnd: number): Promise<void> => {
      const failed: number[] = [];
      for (let i = rangeStart; i < rangeEnd; i++) {
        if (!translatedLines[i]) failed.push(i);
      }
      if (failed.length === 0) return;

      for (const [cStart, cEnd] of clusterAscendingIndices(failed)) {
        if (abortControllerRef.current?.signal.aborted) return;
        try {
          await translateSingleBatch(cStart, cEnd, RETRY_CONTEXT_WINDOW);
        } catch (err) {
          if (isAuthError(err)) throw err;
          // non-auth failures leave slots empty; final soft-fill handles them
        }
        updateProgress(translatedLines.filter(Boolean).length, contentLines.length);
      }
    };

    // Show non-zero progress immediately so users see the modal is alive
    // (a single LLM batch can take 20-60s before the first updateProgress call)
    updateProgress(0.5, contentLines.length);

    // Main loop: run batches in parallel with user-configurable concurrency.
    // Context mode uses `contextBatchSize` — each task sends ~contextWindow
    // lines to the LLM in a single heavy request, so we cap hard. Non-context
    // line-by-line mode uses the separate `batchSize` (see translateBatch
    // below) which is safe to run higher since each request is a single short
    // prompt. Defaults per provider:
    //   - Cloud LLMs (claude, gemini, openai-compat, ...): 3 — under every
    //     mainstream provider's concurrent cap (Claude paid 5-10, DeepSeek
    //     30, Gemini generous). Free-tier users hitting 429 get caught by
    //     pRetry + auto-retry.
    //   - Custom LLM (Ollama local): 1 — Ollama runs inference single-threaded
    //     by default, >1 concurrent would queue on the server and our 180s
    //     requestTimeoutSec would fire on queued requests before they run.
    // Power users with proper paid tiers can raise contextBatchSize in
    // Advanced Settings for faster throughput.
    //
    // Rate-limit safety: pRetry already treats 429 as retryable with backoff,
    // auth errors cascade through abortControllerRef.abort() to stop peers
    // immediately. Each task operates on a disjoint [batchStart, batchEnd)
    // slice of translatedLines — no write contention.
    const batchConcurrency = Math.max(Number(runtimeConfig.contextBatchSize) || 3, 1);
    const batchLimit = pLimit(batchConcurrency);
    const interBatchDelay = runtimeConfig.delayTime ?? 0;

    const batchTasks: Promise<void>[] = [];
    for (let i = 0; i < contentLines.length; i += initialContextWindow) {
      const batchStart = i;
      const batchEnd = Math.min(i + initialContextWindow, contentLines.length);

      batchTasks.push(
        batchLimit(async () => {
          if (abortControllerRef.current?.signal.aborted) return;
          // translateBatch handles context-window halving internally with
          // cluster-aware gap retry. If it still returns false, the post-pass
          // auto-retry (below, after Promise.all) handles it with a 10s
          // breather — the only layer that actually gives rate-limited
          // providers time to reset. translateSingleBatch catches all
          // non-auth errors and returns false, so the only exception that
          // escapes here is isAuthError, which we rethrow so Promise.all
          // rejects and peer tasks abort via the shared signal.
          await translateBatch(batchStart, batchEnd, initialContextWindow);
          // Small gap AFTER each batch — helps severely rate-limited providers.
          // pLimit already throttles concurrency; this adds an optional per-slot
          // pause when users configure delayTime.
          if (interBatchDelay > 0 && !abortControllerRef.current?.signal.aborted) {
            await delay(interBatchDelay);
          }
        }),
      );
    }
    await Promise.all(batchTasks);

    // ─── Auto-retry pass ────────────────────────────────────────────────
    // After the main pass (batches + halved-context retry), any slot still
    // empty most likely hit a rate-limit window or a transient service
    // hiccup — not something pRetry's sub-7s backoff would recover. Wait
    // 10s to let rate-limit counters reset / the service stabilize, then
    // retry via the same cluster helper over the entire range.
    if (translatedLines.some((x) => !x) && !abortControllerRef.current?.signal.aborted) {
      console.log("Auto-retry remaining failed lines after 10s with clustered small-context retry...");
      await delay(10000);
      try {
        await clusterRetryFailures(0, contentLines.length);
      } catch (err) {
        if (isAuthError(err)) throw err;
        // Non-auth: leave remaining failures for the final soft-fill.
      }
    }

    // ─── Final soft-fail ────────────────────────────────────────────────
    // Slots still empty after auto-retry get filled with the original text
    // so the output is usable. Only non-whitespace originals count as real
    // failures — empty/whitespace-only lines (common in subtitle spacing,
    // markdown blank lines) weren't meaningful translations in the first
    // place, so flagging them as failures would just confuse the UI.
    const failedLinesList: string[] = [];
    for (let i = 0; i < translatedLines.length; i++) {
      if (!translatedLines[i]) {
        const original = contentLines[i];
        translatedLines[i] = original;
        if (original && original.trim()) failedLinesList.push(original);
      }
    }
    if (failedLinesList.length > 0) {
      setFailedCount((prev) => prev + failedLinesList.length);
      setFailedLines((prev) => [...prev, ...failedLinesList]);
    }

    return translatedLines;
  };

  // Main translation function
  const translateBatch = async (
    contentLines: string[],
    translationMethodArg: string,
    currentTargetLang: string,
    fileIndex: number = 0,
    totalFiles: number = 1,
    documentType?: "subtitle" | "markdown" | "generic",
  ) => {
    const config = getSelectedConfig();
    const concurrency = Math.max(Number(config?.batchSize) || 10, 1);
    const baseDelay = config?.delayTime || 200;
    const limit = pLimit(concurrency);

    try {
      if (!contentLines.length) return [];

      // Initialize new abort controller for this translation batch
      abortControllerRef.current = new AbortController();

      const updateProgress = makeUpdateProgress(fileIndex, totalFiles);

      const runtimeConfig: TranslationRuntimeConfig = {
        translationMethod: translationMethodArg,
        targetLanguage: currentTargetLang,
        sourceLanguage,
        useCache,
        ...config,
        systemPrompt: effectiveSystemPrompt,
        userPrompt: effectiveUserPrompt,
      };

      // Only create fullText if the prompt uses ${fullText} variable
      const fullText = effectiveUserPrompt.includes("${fullText}") ? contentLines.join("\n") : undefined;

      const cacheSuffix = generateCacheSuffix({
        sourceLanguage,
        targetLanguage: currentTargetLang,
        translationMethod: translationMethodArg,
        config,
        systemPrompt: effectiveSystemPrompt,
        userPrompt: effectiveUserPrompt,
      });

      // Context-aware translation with LLM
      if (documentType && LLM_MODELS.includes(translationMethodArg) && contentLines.length > 1) {
        return await translateWithContext(contentLines, runtimeConfig, cacheSuffix, updateProgress, documentType, fullText);
      }

      if (config?.chunkSize === undefined) {
        // Line-by-line concurrent translation. Soft-fail mirrors LLM context
        // mode (translateWithContext below): a single line's failure fills the
        // slot with the original text and tracks it for the TranslateFailurePanel,
        // letting peers finish. Auth errors (and post-abort cascades) still
        // propagate so Promise.all rejects and the translator catch can route.
        const translatedLines = new Array(contentLines.length);
        const failedLinesList: string[] = [];
        let completedCount = 0;

        const progressStep = Math.max(1, Math.floor(contentLines.length / 100));
        updateProgress(0.5, contentLines.length);

        const promises = contentLines.map((line, index) =>
          limit(async () => {
            if (abortControllerRef.current?.signal.aborted) return;
            try {
              translatedLines[index] = await translateSingle(line, cacheSuffix, runtimeConfig, fullText);
            } catch (error) {
              // Auth error already tripped abortControllerRef inside translateSingle.
              // After-abort throws ("Translation aborted") come from peers' pre-attempt
              // guard. Both must propagate so Promise.all kills the batch — translator
              // catch surfaces the real auth error / handles cascade silently.
              if (isAuthError(error) || abortControllerRef.current?.signal.aborted) throw error;
              // Otherwise (network blip, 5xx, etc., after pRetry exhausted):
              // soft-fail this line, keep peers running.
              translatedLines[index] = line;
              if (line && line.trim()) failedLinesList.push(line);
            }
            completedCount++;
            if (completedCount % progressStep === 0 || completedCount === contentLines.length) {
              updateProgress(completedCount, contentLines.length);
            }
            if (baseDelay > 0 && completedCount < contentLines.length) {
              await delay(baseDelay);
            }
          }),
        );

        await Promise.all(promises);
        updateProgress(contentLines.length, contentLines.length);

        // Surface failures via the same channel as context-mode (TranslateFailurePanel).
        if (failedLinesList.length > 0) {
          setFailedCount((prev) => prev + failedLinesList.length);
          setFailedLines((prev) => [...prev, ...failedLinesList]);
        }

        return translatedLines;
      }

      // Chunk-based concurrent translation.
      //
      // WHY NOT join→translate→split:
      // Joining lines with "\n" then splitting the translated result by "\n"
      // breaks when any line is empty — an empty line becomes an extra "\n"
      // in the joined text, so the split result has MORE elements than the
      // original, shifting every subsequent line's index. This silently maps
      // the wrong translation to the wrong subtitle line.
      //
      // SOLUTION: track which contentLines indices each chunk covers, then
      // map translated lines back by per-chunk position — no global index
      // arithmetic that can drift.
      const delimiter = translationMethodArg === "deeplx" ? "<>" : "\n";
      const chunkSizeVal = config?.chunkSize || 5000;

      // Build chunks directly from contentLines, recording start index for each.
      interface ChunkInfo { text: string; lines: string[]; startIdx: number }
      const chunkInfos: ChunkInfo[] = [];
      {
        const parts: string[] = [];
        let currentChars = 0;
        let chunkStart = 0;

        const flushChunk = () => {
          if (parts.length === 0) return;
          chunkInfos.push({
            text: parts.join(delimiter),
            lines: [...parts],
            startIdx: chunkStart,
          });
          chunkStart += parts.length;
          parts.length = 0;
          currentChars = 0;
        };

        for (const line of contentLines) {
          const addedLen = parts.length > 0 ? delimiter.length + line.length : line.length;
          if (currentChars + addedLen > chunkSizeVal && parts.length > 0) flushChunk();
          parts.push(line);
          currentChars += parts.length === 1 ? line.length : delimiter.length + line.length;
        }
        flushChunk();
      }

      const translatedLines = new Array<string>(contentLines.length);
      const chunkFailedLines: string[] = [];

      const chunkTasks = chunkInfos.map(({ text, lines, startIdx }, i) =>
        limit(async () => {
          try {
            const translatedContent = await translateSingle(text, cacheSuffix, runtimeConfig, fullText);
            const decoded =
              translationMethodArg === "deeplx"
                ? (translatedContent || "").replace(/<>/g, "\n")
                : translatedContent || "";
            // Split translated result by the same delimiter used to build the chunk.
            // Map each position back to the exact contentLines index — immune to
            // index drift regardless of how many empty lines are in the file.
            const resultLines = decoded.split(delimiter);
            // First pass: map translated lines back by index.
            // Collect lines the API skipped (line-count mismatch) for
            // individual retry — their cache key differs from the chunk key,
            // so individual calls bypass the cached partial result entirely.
            const missingJs: number[] = [];
            for (let j = 0; j < lines.length; j++) {
              const contentIdx = startIdx + j;
              if (contentIdx >= contentLines.length) break;
              const original = contentLines[contentIdx];
              const translated = resultLines[j];
              if (!original?.trim()) {
                translatedLines[contentIdx] = original || "";
              } else if (translated?.trim()) {
                translatedLines[contentIdx] = translated;
              } else {
                missingJs.push(j);
                translatedLines[contentIdx] = original; // placeholder
              }
            }
            // Second pass: retry each missing line individually.
            // WHY: the chunk result was cached (HTTP 200 but wrong line count).
            // Retrying the whole chunk would hit that same cache and return the
            // same partial result forever. A single-line request has a different
            // cache key, forces a fresh API call, and caches the correct result.
            for (const j of missingJs) {
              const contentIdx = startIdx + j;
              if (contentIdx >= contentLines.length) break;
              if (abortControllerRef.current?.signal.aborted) break;
              const original = contentLines[contentIdx];
              try {
                const retried = await translateSingle(original, cacheSuffix, runtimeConfig, fullText);
                if (retried?.trim()) {
                  translatedLines[contentIdx] = retried;
                } else {
                  // Individual retry also returned empty — genuinely failed.
                  chunkFailedLines.push(original);
                }
              } catch (lineErr) {
                if (isAuthError(lineErr) || abortControllerRef.current?.signal.aborted) throw lineErr;
                chunkFailedLines.push(original);
              }
            }
          } catch (error) {
            // Auth errors and cascaded aborts must propagate — same contract
            // as line-by-line mode so Promise.all stops all peers correctly.
            if (isAuthError(error) || abortControllerRef.current?.signal.aborted) throw error;
            // Any other failure (network, 5xx, rate-limit after retries):
            // soft-fail every line in this chunk so the rest keep translating.
            for (let j = 0; j < lines.length; j++) {
              const contentIdx = startIdx + j;
              if (contentIdx >= contentLines.length) break;
              translatedLines[contentIdx] = contentLines[contentIdx];
              if (contentLines[contentIdx]?.trim()) chunkFailedLines.push(contentLines[contentIdx]);
            }
          }

          // Progress based on lines translated so far (more accurate than chunk count).
          updateProgress(translatedLines.filter((l) => l !== undefined).length, contentLines.length);
          if (baseDelay > 0 && i < chunkInfos.length - 1) await delay(baseDelay);
        }),
      );

      await Promise.all(chunkTasks);

      // Safety net: any slot still undefined (shouldn't happen, but guards
      // against future code paths missing an assignment).
      for (let i = 0; i < contentLines.length; i++) {
        if (translatedLines[i] === undefined) {
          translatedLines[i] = contentLines[i];
          if (contentLines[i]?.trim()) chunkFailedLines.push(contentLines[i]);
        }
      }

      // Surface all failures through the retry panel — same channel as
      // line-by-line mode so "Retry" works and cache skips successful lines.
      if (chunkFailedLines.length > 0) {
        setFailedCount((prev) => prev + chunkFailedLines.length);
        setFailedLines((prev) => [...prev, ...chunkFailedLines]);
      }

      return translatedLines;

    } catch (error) {
      console.error("Error translating content:", error);
      throw error;
    }
  };

  // Translation handlers
  const runTranslation = async (performTranslation: PerformTranslation, sourceText: string, documentType?: "subtitle" | "markdown" | "generic") => {
    setTranslatedText("");
    // Reset soft-failure state for this run — the UI Alert is driven by these.
    setFailedCount(0);
    setFailedLines([]);
    setFailedLangs([]);
    if (!sourceText.trim()) {
      message.error("No source text provided.");
      return;
    }

    // isTranslating 现在统一在 runTranslation 这一层管,validate 内部不再
    // 自行开关。Progress modal 在 validate 的 test ping 阶段也保持可见,体验连续。
    setIsTranslating(true);
    resetProgress();
    try {
      const isValid = await validate();
      if (!isValid) return;
      await performTranslation(sourceText, undefined, undefined, undefined, documentType);
    } finally {
      setIsTranslating(false);
    }
  };

  return {
    exportSettings,
    importSettings,
    translationMethod,
    setTranslationMethod,
    translationConfigs,
    getSelectedConfig,
    handleConfigChange,
    resetTranslationConfig,
    systemPrompt,
    setSystemPrompt,
    userPrompt,
    setUserPrompt,
    useCache,
    setUseCache,
    removeChars,
    setRemoveChars,
    translateSingle,
    translateBatch,
    runTranslation,
    sourceLanguage,
    targetLanguage,
    targetLanguages,
    setTargetLanguages,
    multiLanguageMode,
    setMultiLanguageMode,
    translatedText,
    setTranslatedText,
    failedCount,
    failedLines,
    failedLangs,
    setFailedLangs,
    isTranslating,
    setIsTranslating,
    apiSettingsOpen,
    setApiSettingsOpen,
    progressPercent,
    setProgressPercent,
    progressInfo,
    handleLanguageChange,
    handleSwapLanguages,
    retryCount,
    setRetryCount,
    requestTimeoutSec,
    setRequestTimeoutSec,
    validate,
    llmPresets,
    activeLlmPresetId,
    saveLlmPreset,
    loadLlmPreset,
    deleteLlmPreset,
    renameLlmPreset,
    updateLlmPreset,
    promptPresets,
    setPromptPresets,
    activePromptPresetId,
    setActivePromptPresetId,
    savePromptPreset,
    loadPromptPreset,
    deletePromptPreset,
    renamePromptPreset,
    updatePromptPreset,
  };
};

export default useTranslationState;
