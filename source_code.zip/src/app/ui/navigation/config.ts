/**
 * Navigation Configuration Constants
 * 导航栏配置常量 - 通用配置，可同步到子项目
 */

// ============ 社交链接配置 ============

/**
 * 社交链接配置
 * Social links configuration
 */
export const SOCIAL_LINKS = {
  discord: "https://discord.gg/PZTQfJ4GjX",
  telegram: "https://t.me/ifitworkitwork",
  qq: "https://qm.qq.com/q/uWsUSnyivm",
} as const;
